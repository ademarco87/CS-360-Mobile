package com.example.nocakeweight;

public class DataItem {
    private final String data;
    private final String timestamp;

    public DataItem(String data, String timestamp) {
        this.data = data;
        this.timestamp = timestamp;
    }

    public String getData() {
        return data;
    }

    public String getTimestamp() {
        return timestamp;
    }
}
