package com.example.nocakeweight;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.TextView;

import java.util.ArrayList;

public class DataAdapter extends ArrayAdapter<DataItem> {
    private final Context context;
    private final ArrayList<DataItem> dataItems;

    public DataAdapter(Context context, ArrayList<DataItem> dataItems) {
        super(context, 0, dataItems);
        this.context = context;
        this.dataItems = dataItems;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        // Get the data item for this position
        DataItem dataItem = getItem(position);

        // Check if an existing view is being reused, otherwise inflate the view
        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.grid_item_data, parent, false);
        }

        // Lookup view for data population
        TextView textViewData = convertView.findViewById(R.id.textViewData);
        TextView textViewTimestamp = convertView.findViewById(R.id.textViewTimestamp);
        Button buttonDelete = convertView.findViewById(R.id.buttonDelete);

        // Populate the data into the template view using the data object
        textViewData.setText(dataItem.getData());
        textViewTimestamp.setText(dataItem.getTimestamp());

        // Set delete button action
        buttonDelete.setOnClickListener(v -> {
            dataItems.remove(position);
            notifyDataSetChanged();
        });

        // Return the completed view to render on screen
        return convertView;
    }
}
