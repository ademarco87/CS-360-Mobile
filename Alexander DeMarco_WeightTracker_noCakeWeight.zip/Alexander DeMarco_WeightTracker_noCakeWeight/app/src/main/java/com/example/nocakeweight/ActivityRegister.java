package com.example.nocakeweight;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class ActivityRegister extends AppCompatActivity {

    private EditText editTextUsername;
    private EditText editTextPassword;
    private EditText editTextWeightGoal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        editTextUsername = findViewById(R.id.editTextUsername);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextWeightGoal = findViewById(R.id.editTextWeightGoal);

        Button buttonRegister = findViewById(R.id.buttonRegister);
        buttonRegister.setOnClickListener(v -> registerUser());
    }

    private void registerUser() {
        String username = editTextUsername.getText().toString().trim();
        String password = editTextPassword.getText().toString().trim();
        String weightGoalString = editTextWeightGoal.getText().toString().trim();

        if (username.isEmpty() || password.isEmpty() || weightGoalString.isEmpty()) {
            Toast.makeText(this, "Please fill in all fields", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            int weightGoal = Integer.parseInt(weightGoalString);

            // Show a success message
            Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();

            // Navigate to ActivityDataDisplay and pass the weight goal
            Intent intent = new Intent(ActivityRegister.this, ActivityDataDisplay.class);
            intent.putExtra("weight_goal", weightGoal);
            startActivity(intent);
            finish(); // Optionally close the registration activity

        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid weight goal", Toast.LENGTH_SHORT).show();
        }
    }
}
