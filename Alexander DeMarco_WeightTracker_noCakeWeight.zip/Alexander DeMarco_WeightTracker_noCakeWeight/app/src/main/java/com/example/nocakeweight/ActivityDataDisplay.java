package com.example.nocakeweight;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class ActivityDataDisplay extends AppCompatActivity {

    private ArrayList<DataItem> dataItems;
    private DataAdapter dataAdapter;
    private GridView gridViewData;
    private EditText editTextWeight;
    private TextView textViewWeightGoal; // TextView to display weight goal

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_display);

        gridViewData = findViewById(R.id.gridViewData);
        editTextWeight = findViewById(R.id.editTextWeight);
        textViewWeightGoal = findViewById(R.id.textViewWeightGoal); // Initialize the TextView

        dataItems = new ArrayList<>();
        dataAdapter = new DataAdapter(this, dataItems);
        gridViewData.setAdapter(dataAdapter);

        // Retrieve weight goal from the intent and display it
        int weightGoal = getIntent().getIntExtra("weight_goal", 0);
        textViewWeightGoal.setText("Weight Goal: " + weightGoal + " lbs");

        Button buttonAddData = findViewById(R.id.buttonAddData);
        buttonAddData.setOnClickListener(v -> addNewData());
    }

    private void addNewData() {
        String newData = editTextWeight.getText().toString().trim();
        if (newData.isEmpty()) {
            Toast.makeText(this, "Please enter a weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // Parse the entered weight as an integer
        int enteredWeight;
        try {
            enteredWeight = Integer.parseInt(newData);
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Please enter a valid weight", Toast.LENGTH_SHORT).show();
            return;
        }

        // Retrieve the weight goal
        String weightGoalText = textViewWeightGoal.getText().toString();
        int weightGoal = Integer.parseInt(weightGoalText.replaceAll("[^0-9]", ""));

        // Check if the entered weight matches the goal weight
        if (enteredWeight == weightGoal) {
            Toast.makeText(this, "Congratulations! You've reached your weight goal!", Toast.LENGTH_LONG).show();
        }

        // Get current timestamp
        String timestamp = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        // Create new DataItem and add it to the list
        dataItems.add(new DataItem(newData, timestamp));
        dataAdapter.notifyDataSetChanged();

        // Clear the input field after adding data
        editTextWeight.setText("");
    }
}