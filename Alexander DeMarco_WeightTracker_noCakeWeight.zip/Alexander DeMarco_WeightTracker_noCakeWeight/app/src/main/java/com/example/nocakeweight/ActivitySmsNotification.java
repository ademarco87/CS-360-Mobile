package com.example.nocakeweight;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class ActivitySmsNotification extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 101; // Request code for SMS permission
    private TextView textViewStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms_notification); // Your SMS notification layout file

        textViewStatus = findViewById(R.id.textViewStatus);
        Button buttonRequestPermission = findViewById(R.id.buttonRequestPermission);

        // Check for SMS permission when the activity starts
        checkSmsPermission();

        buttonRequestPermission.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                requestSmsPermission();
            }
        });
    }

    private void checkSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) != PackageManager.PERMISSION_GRANTED) {
            textViewStatus.setText("You need to grant SMS permission to receive notifications.");
        } else {
            textViewStatus.setText("SMS permission granted! You will receive notifications.");
        }
    }

    private void requestSmsPermission() {
        ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.SEND_SMS}, SMS_PERMISSION_CODE);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                textViewStatus.setText("SMS permission granted! You will receive notifications.");
                // Proceed with sending notifications
            } else {
                textViewStatus.setText("SMS permission denied. You won't receive notifications.");
                // Handle the case where permission is denied
            }
        }
    }
}
